package com.example.CurrencyService.entity;

import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.util.List;

@Data
@Entity


public class Currency {

  @Id @GeneratedValue Integer id;

  @Length(min = 2, max = 3)
  String code;

  @Max(3)
  int digitsAfterDecimal;

  @NotBlank
  @Length(min = 5)
  String name;

  @NotEmpty
  @ElementCollection
  List<String> countriesList;
}
