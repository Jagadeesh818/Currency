package com.example.CurrencyService.service;

import com.example.CurrencyService.entity.Currency;
import com.example.CurrencyService.repository.CurrencyRepository;
import lombok.extern.apachecommons.CommonsLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@CommonsLog
public class CurrencyService {

  @Autowired private CurrencyRepository currencyRepository;

  @Transactional
  public Currency saveCurrency(Currency currency) {
    return this.currencyRepository.save(currency);
  }

  @Cacheable(value="Currency", key="#id")
  public Optional<Currency> getCurrencyById(Integer id) {
    log.info("returned from Database");
    return this.currencyRepository.findById(id);
  }

  public List<Currency> getAllCurrencies() {
    return this.currencyRepository.findAll();
  }
}
