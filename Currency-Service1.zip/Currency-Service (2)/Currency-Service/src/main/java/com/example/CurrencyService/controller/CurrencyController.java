package com.example.CurrencyService.controller;

import com.example.CurrencyService.entity.Currency;
import com.example.CurrencyService.service.CurrencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/currency")
public class CurrencyController {
  @Autowired private CurrencyService currencyService;

  @PostMapping
  public ResponseEntity<Currency> saveCurrency(@RequestBody @Valid Currency inputCurrency) {
    Currency savedCurrency = this.currencyService.saveCurrency(inputCurrency);
    return new ResponseEntity<>(savedCurrency, HttpStatus.CREATED);
  }

  @GetMapping("/{id}")
  public ResponseEntity<Currency> getCurrencyById(@PathVariable("id") Integer currentId) {

    Optional<Currency> optCurrency = this.currencyService.getCurrencyById(currentId);
    if (optCurrency.isPresent()) return new ResponseEntity<>(optCurrency.get(), HttpStatus.OK);
    return new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  @GetMapping
  public ResponseEntity<List<Currency>> getCurrencyList() {
    return new ResponseEntity<>(this.currencyService.getAllCurrencies(), HttpStatus.OK);
  }
}
