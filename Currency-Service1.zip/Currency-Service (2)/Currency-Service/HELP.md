# Read Me
-- build Project : mvn spring-boot:run

# Fetaures

    - Data Base Integration
    - Transaction Management
    - Validation
    - Rest API
    - Transaction Management
    - REST CUstom Status Codes
    - JPA Elemenet COllection
    - Caching
    - Lombok
    - Scheduling
    - Cache Eviction Ploicy

# Rest Examples: POST
    - http://localhost:8080/currency
            {
                
                "code": "USD",
                "digitsAfterDecimal": 2,
                "name": "AMerican Dollors",
                "countriesList": ["USA","CANADA"]
            }

# Rest Examples: GET 